#ifndef __CREDIT_LAYER_H__
#define __CREDIT_LAYER_H__

#include "cocos2d.h"

class CreditLayer :public cocos2d::Layer
{
public:

	/// <summary>
	/// Init credit layer.
	/// </summary>
	/// <returns></returns>
	virtual bool init();

	CREATE_FUNC(CreditLayer);

private:


};



#endif